#!/bin/bash

before="[GriloSub] Dagashi Kashi - 01 [E9C15C49].mkv"
after="[GriloSub] Dagashi Kashi - 01v2 [2EE4C3E7].mkv"
app="xdelta"

function check_wine {
  hash wine 2>&- && {
    app="wine xdelta3.exe"
  } || {
    echo $1;
    echo "Please install either wine or xdelta3.";
    exit 1;
  }
}

hash xdelta3 2>&- && {
  app="xdelta3";
} || {
  hash xdelta 2>&- && {
    $app -D > /dev/null 2> /dev/null;
    if [ $? -eq 2 ]; then
      check_wine "Wine is not installed and the xdelta installed is of an older version.";
    fi
  } || {
    check_wine "Neither wine or xdelta is installed.";
  }
}

output=`$app -d -s "$before" "patch.delta" "$after"`
if [ $? -ne 0 ];
  then
    echo $output;
    echo "Press enter to exit.";
  else
    echo "Done, your file was patched successfully. Press enter to exit.";
fi
read
exit 0;
